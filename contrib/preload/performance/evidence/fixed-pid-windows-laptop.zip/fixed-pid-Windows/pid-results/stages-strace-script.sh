#!/bin/bash
# Preload the worktree Git and make a few calls so strace can show how the
# GET reply is read on Windows. Arguments: library path, git.exe path.
set -u
source "$1" || exit 31
preload "$2" || exit 32
git --version >/dev/null || exit 33
echo MARK-BEGIN >/dev/null
for i in 1 2 3; do
  git --version >/dev/null || exit 34
done
echo MARK-END >/dev/null
_preload_stop
