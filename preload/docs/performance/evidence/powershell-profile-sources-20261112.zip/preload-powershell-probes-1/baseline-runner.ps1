#requires -Version 7.0
<#
.SYNOPSIS
Validate or time the experimental Windows PowerShell preload client.
.PARAMETER Git
Native path to the built Git. Its runtime DLLs must be on PATH.
.PARAMETER Python
Native Python executable for the shared manager.
.PARAMETER Output
New artifact directory, containing a report and session logs.
.PARAMETER Mode
Test performs correctness checks; Preload and Direct collect warmed latency.
.PARAMETER Count
Positive number of measured calls, excluding twenty warm-up calls.
.PARAMETER DiscardOutput
Time the null-sink path instead of capturing and decoding command output.
#>
param(
    [string] $Git,
    [string] $Python,
    [string] $Output,
    [ValidateSet('Test', 'Preload', 'Direct')] [string] $Mode = 'Test',
    [ValidateRange(1, 100000)] [int] $Count = 200,
    [switch] $DiscardOutput
)
$ErrorActionPreference = 'Stop'
. 'C:\Users\adria\AppData\Local\Temp\preload-powershell-probes-1\baseline.ps1'
$Git = (Resolve-Path -LiteralPath $Git).ProviderPath
$null = New-Item -ItemType Directory -Path $Output -Force
$Output = (Resolve-Path -LiteralPath $Output).ProviderPath

function Invoke-DirectCapture {
    <#
    .SYNOPSIS
    Capture a native Git invocation concurrently as the correctness oracle.
    .PARAMETER Words
    Exact argument array, excluding the executable; empty strings preserved.
    #>
    param([AllowEmptyCollection()] [AllowEmptyString()] [string[]] $Words)
    $info = [System.Diagnostics.ProcessStartInfo]::new()
    $info.FileName = $Git
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.WorkingDirectory = (Get-Location).ProviderPath
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    foreach ($word in $Words) { $info.ArgumentList.Add($word) }
    $process = [System.Diagnostics.Process]::Start($info)
    try {
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(15000)) {
            $process.Kill($true)
            throw 'Direct command timed out'
        }
        return [pscustomobject]@{
            Stdout = $stdout.GetAwaiter().GetResult()
            Stderr = $stderr.GetAwaiter().GetResult()
            ExitCode = $process.ExitCode
        }
    } finally { $process.Dispose() }
}

try {
    if ($Mode -ne 'Direct') {
        Start-Preload -Executable $Git -Python $Python -Directory (Join-Path $Output 'session')
    }
    if ($Mode -eq 'Test') {
        $fixture = Join-Path $Output 'space ü repo'
        $null = Invoke-DirectCapture @('init', '-q', $fixture)
        $config = Join-Path $fixture 'arguments.config'
        $null = Invoke-DirectCapture @('config', '--file', $config, 'test.value', 'héllo 世界')
        $alias = '!f() { printf "<%s>\n" "$@"; }; f'
        $large = '!f() { i=0; while test "$i" -lt 4000; do printf "stdout-0123456789\n"; printf "stderr-0123456789\n" >&2; i=$((i+1)); done; }; f'
        $cases = @(
            @{ Name = 'version'; Words = @('--version') },
            @{ Name = 'zero-arguments'; Words = @() },
            @{ Name = 'cwd'; Words = @('rev-parse', '--show-toplevel') },
            @{ Name = 'unicode-path-value'; Words = @('config', '--file', $config, '--get', 'test.value') },
            @{ Name = 'arguments'; Words = @('-c', "alias.echo=$alias", 'echo', '', 'a b', 'quote"value', 'héllo 世界', "line`nbreak", 'END') },
            @{ Name = 'nonzero-stderr'; Words = @('not-a-real-subcommand') },
            @{ Name = 'large-both-streams'; Words = @('-c', "alias.large=$large", 'large') }
        )
        $passed = @()
        Push-Location -LiteralPath $fixture
        try {
            foreach ($case in $cases) {
                $expected = Invoke-DirectCapture -Words $case.Words
                $actual = Invoke-Preload -Arguments $case.Words
                if ($actual.Stdout -cne $expected.Stdout -or
                    $actual.Stderr -cne $expected.Stderr -or
                    $actual.ExitCode -ne $expected.ExitCode -or
                    $global:LASTEXITCODE -ne $actual.ExitCode) {
                    throw "Mismatch: $($case.Name): $($actual | ConvertTo-Json -Compress)"
                }
                $passed += $case.Name
                $discarded = Invoke-Preload -Arguments $case.Words -DiscardOutput
                if ($discarded -isnot [int] -or $discarded -ne $expected.ExitCode -or
                    $global:LASTEXITCODE -ne $expected.ExitCode) {
                    throw "Discard mismatch: $($case.Name)"
                }
                $passed += ('discard-' + $case.Name)
            }
            $overflow = $false
            try { $null = Invoke-Preload -Arguments ([string[]]::new(65536)) }
            catch { $overflow = $_.Exception.Message -like '*65535*' }
            if (-not $overflow) { throw 'Argument overflow was not rejected' }
            $passed += 'overflow-rejected'
            $many = @('rev-parse', '--sq-quote') + (@('') * 65533)
            $actual = Invoke-Preload -Arguments $many
            if ($actual.ExitCode -ne 0 -or $actual.Stderr -ne '' -or
                $actual.Stdout -cne ((' ' + "''") * 65533 + "`n")) {
                throw '65535-parameter request failed'
            }
            $passed += '65535-parameters'
            $null = Invoke-Preload -Arguments @('--version')
            $passed += 'recovery'
        } finally { Pop-Location }
        $report = @{ Mode = $Mode; Passed = $passed; PowerShell = $PSVersionTable.PSVersion.ToString() }
    } else {
        $samples = [System.Collections.Generic.List[double]]::new()
        for ($i = -20; $i -lt $Count; $i++) {
            # Give the same one-command refill interval to both clients.
            & $Git --version > $null
            $watch = [System.Diagnostics.Stopwatch]::StartNew()
            if ($Mode -eq 'Preload') {
                $result = Invoke-Preload -Arguments @('--version') -DiscardOutput:$DiscardOutput
                $code = if ($DiscardOutput) { $result } else { $result.ExitCode }
                if ($code -ne 0) { throw 'Preloaded benchmark command failed' }
            } else {
                & $Git --version > $null
                if ($LASTEXITCODE -ne 0) { throw 'Direct benchmark command failed' }
            }
            $watch.Stop()
            if ($i -ge 0) { $samples.Add($watch.Elapsed.TotalMilliseconds) }
        }
        $report = @{ Mode = $Mode; DiscardOutput = [bool]$DiscardOutput
            SamplesMs = $samples.ToArray(); PowerShell = $PSVersionTable.PSVersion.ToString() }
    }
    $report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $Output 'report.json') -Encoding utf8
    Write-Output "PRELOAD_POWERSHELL_PASS $Mode"
} finally { Stop-Preload }
